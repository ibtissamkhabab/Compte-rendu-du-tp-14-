package TP14_1

// Q1 : Créer une fonction verifierDisponibilite (2 secondes)

import kotlinx.coroutines.*

suspend fun verifierDisponibilite() {
    println("Vérification des ingrédients...")
    delay(2000)
    println("Ingrédients disponibles ")
}


//--------------------------------------------------------------------------

// Q2 : Créer une fonction preparerCommande (5 secondes)

suspend fun preparerCommande() {
    println("Préparation de la commande...")
    delay(5000)
    println("Commande prête ")
}



//--------------------------------------------------------------------------------

// Q3 : Créer une fonction livrerRepas (3 secondes) avec Dispatchers.IO

suspend fun livrerRepas() = withContext(Dispatchers.IO) {
    println("Livraison du repas...")
    delay(3000)
    println("Repas livré ")
}


// Q4 : Utiliser des coroutines pour exécuter les trois fonctions dans l'ordre logique

fun main() = runBlocking {
    println("Début du processus de commande ")

    verifierDisponibilite()
    val preparation = async { preparerCommande() }
    val livraison = async { livrerRepas() }

    preparation.await()
    livraison.await()

    println("Commande terminée ")
}


